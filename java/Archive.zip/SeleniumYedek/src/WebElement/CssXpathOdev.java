package WebElement;

public class CssXpathOdev {
    public static void main(String[] args) {

        //bu çalışmayı hem xpath locatorlar kullanarak yapalım hemde css locatorlar kullanarak yapalım.
        //1. amazona gidelim.
        //2. "toshiba 32 gb 4800 mhz ram" arama yapalım
        //3. çıkan ilk 10 sonuç için ortalama fiyat analizi yapalım.  (liste kullanarak yapalım)





    }
}
