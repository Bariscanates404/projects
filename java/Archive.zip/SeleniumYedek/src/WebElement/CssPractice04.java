package WebElement;

public class CssPractice04 {
    public static void main(String[] args) {
        //1. https://www.bestbuy.com/ a gidin.
        //2. sayfanın en alt kısmında bulunan in store pricing bilgi yazısını önce bir String değişkene
        // sonrasında consola bastırınız.




    }
}
